import yfinance as yf 
#from garbage import give_price , get_date , give_price_failsafe , prediction_page 
import numpy as np 

close =  yf.download("ADANIENT.NS",period="4d")["Close"].values / 1000 
try : 
    inputs = np.array(close).reshape(1,3,1)
except : 
    close = close[1:]
    inputs = np.array(close).reshape(1,3,1)


print(inputs[0][3])